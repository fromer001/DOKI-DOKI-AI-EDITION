Halogen Font

Halogen is a handwriting font designed only by me using only FontLab Studio 5 - no paper, pencil or sketching was done. Like all other JLH Fonts, this font is in the public domain and comes with the Euro sign.

Check out our other fonts, such as:

- Apex Lake
- Portmanteau
- Remix
- Sierra Nevada Road
- Grunge Handwriting
- Hand Drawn Shapes
- Seattle Avenue
- Overhaul